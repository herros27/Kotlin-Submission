package com.dicoding.exam.optionalexam5

// TODO
val concatString:(string1: String, string2: String)-> String = String::plus
